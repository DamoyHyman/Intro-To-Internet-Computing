<!DOCTYPE html>
<html lang="en">

  <head>
      <!-- Global site tag (gtag.js) - Google Analytics -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-110491194-1"></script>
      <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

            gtag('config', 'UA-110491194-1');
      </script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>GearHead Inc</title>
      <!-- Other CSS -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="css/mycss1.css">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-home.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>

  <body>
      

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.html">GearHead Blogs</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
              
              <!--- Display welcome for logged in user -->
              <?php
                     session_start();
                    if (isset($_SESSION['Username']) && isset($_SESSION['Mem_ID']))
                    {
                        echo '<li class="nav-item active">';
                        echo '<a class="nav-link" href="index.php">Welcome: ';
                        echo $_SESSION['Username'] ."!";
                        echo '<span class="sr-only">(current)</span>';
                        echo '</a>';
                        echo '</li>';
                    }
              ?>
              
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
              
              <?php
                if (!isset($_SESSION['Username']) && !isset($_SESSION['Mem_ID']))
                {
                    echo '<li class="nav-item">';
                    echo '<a class="nav-link" href="login.php">MyAccount';
                    echo '</a>';
                    echo '</li>';
                }
              ?>
              
            <li class="nav-item">
              <a class="nav-link" href="#About">About</a>
              </li>
    
              <li class="nav-item">
                  <div class="dropdown">
                     <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services
                      </button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="write_new_blog_form.php">Write a Blog</a>
                        <a class="dropdown-item" href="#">List item for sale</a>
                        <a class="dropdown-item" href="#Parts Lists">Browse items for sale</a>
                        <a class="dropdown-item" href="#">Post Videos</a>
                        <a class="dropdown-item" href="#">Chat</a>
                        <?php
                          if (isset($_SESSION['Username']) && isset($_SESSION['Mem_ID']))
                          {
                              echo '<a class="dropdown-item" href="googleAnalytics.png">Google Analytics</a>';
                          }
                        ?>  
                    </div>
                  </div>
              </li>
              
               <!--- Display logout for logged in user -->
               <?php
                if (isset($_SESSION['Username']) && isset($_SESSION['Mem_ID']))
                 {
                    
                        echo '<li class="nav-item active">';
                        echo '<a class="nav-link" href="logout.php">logout';
                        echo '<span class="sr-only">(current)</span>';
                        echo '</a>';
                        echo '</li>';
                }
              ?>
              
            <li class="nav-item">
              <!--<a class="nav-link" href="#">Contact</a>-->
                
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

          <h1 class="my-4"><em>The Latest and Greatest
            <small>Automobile Trends</small>
              </em></h1>

          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="myimg/2018-Aston-Martin-DB11-V8-front-three-quarter-in-motion-02-close-crop.jpg" style="width:729px; height:300px;" alt="2018 Aston Martin DB11 V8">
            <div class="card-body">
              <h2 class="card-title">2018 ASTON MARTIN DB11 V8 FIRST DRIVE</h2>
              <p class="card-text">Compared with the V-12-powered car that launched the all-new DB11 range last year, the 2018 Aston Martin DB11 V8 has four fewer cylinders, develops 97 hp less, and its torque output falls short by 18 lb-ft. And it’s the better car for it. The DB11 V8 looks virtually identical to its gorgeous V12 powered sibling. But under that thrusting hood is one of our favorite engines—the thundering 4.0-liter twin-turbo V-8 developed by AMG, whose parent company, Daimler, owns a 5 percent stake in Aston Martin.</p>
              <a href="http://www.motortrend.com/cars/aston-martin/db11/2018/2018-aston-martin-db11-v8-first-drive/" class="btn btn-primary">Read More &rarr;</a>
            </div>
            <div class="card-footer text-muted">
              Posted on September 26, 2017 on MotorTrend by
              <a href="http://www.motortrend.com/staff/angus-mackenzie/">Angus MacKenzie</a>
            </div>
          </div>

          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="myimg/bmw-2-series-gran-coupe-rendering-830x553.jpg" alt="Card image cap" style="width:729px; height:300px;">
            <div class="card-body">
              <h2 class="card-title">BMW F44 2 Series Gran Coupe reportedly coming to the U.S.</h2>
              <p class="card-text">The BMW 2 Series family in the U.S. consists of a coupe and convertible model, but starting in 2020, it will gain a new family member. The 2 Series Gran Coupe has been rumored for years now and according to our sources, the four-door entry-level coupe will arrive on this side of the pond. Earlier today, first spy shots of the 2er Gran Coupe surfaced on the interwebs, in a way a confirmation to the numerous rumors.</p>
              <a href="http://www.bmwblog.com/2017/09/26/bmw-f44-2-series-gran-coupe-reportedly-coming-u-s/" class="btn btn-primary">Read More &rarr;</a>
            </div>
            <div class="card-footer text-muted">
              Posted on September 26, 2017 on BMW Blog by
              <a href="http://www.bmwblog.com/author/admin/">Horatiu Boeriu</a>
            </div>
          </div>

          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="myimg/2018-Honda-Accord-Touring-grey.jpg" alt="2018 Honda Accord" style="width:729px; height:300px;">
            <div class="card-body">
              <h2 class="card-title">The 2018 Honda Accord Gets Tech the Entire Acura Brand Can’t Yet Have</h2>
              <p class="card-text">The Honda Accord is by no means a younger sibling, operating as the senior member of American Honda’s fleet.
              More specifically, the 2018 Honda Accord will never be viewed as the little brother in the American Honda family, not with these substantial dimensions and MSRPs that reach deep into the $30Ks.But the 10th-generation Accord is still a Honda. Just a Honda. Merely a Honda. Only a Honda. And while you might expect Honda to enjoy technological hand-me-downs from the automaker’s upmarket Acura brand, that’s not the way it works. Not when it comes to the Accord. As a result, we’ll wait and see which hand-me-ups appear on the next all-new Acura, the third-generation 2019 Acura RDX.</p>
              <a href="http://www.thetruthaboutcars.com/2017/08/2018-honda-accord-gets-tech-acura-brand-cant-yet/#more-1585162" class="btn btn-primary">Read More &rarr;</a>
            </div>
            <div class="card-footer text-muted">
              Posted on August 15, 2017 by
              <a href="http://www.thetruthaboutcars.com/author/timothy-cain/">Timothy Cain</a>
            </div>
          </div>

          <!-- Pagination -->
          <ul class="pagination justify-content-center mb-4">
            <li class="page-item">
              <a class="page-link" href="#">&larr; Older</a>
            </li>
            <li class="page-item">
              <a class="page-link" href="newer_blog.php">Newer &rarr;</a>
            </li>
          </ul>

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

          <!-- Search Widget -->
          <div class="card my-4">
            <h5 class="card-header">Search Blogs</h5>
            <div class="card-body">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                  <button class="btn btn-secondary" type="button">Go!</button>
                </span>
              </div>
            </div>
          </div>
            
            <div class="card my-4">
            <h5 class="card-header">Search Parts</h5>
            <div class="card-body">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                  <button class="btn btn-secondary" type="button">Go!</button>
                </span>
              </div>
            </div>
          </div>

          <!-- Categories Widget -->
          <div class="card my-4">
              <a name="Parts Lists"><h5 class="card-header">Parts Lists</h5></a>
            <div class="card-body">
              <div class="row">
                <div class="col-lg-6">
                  <ul class="list-unstyled mb-0">
                    <li>
                      <a href="#">Suspension</a>
                    </li>
                    <li>
                      <a href="#">Intake System</a>
                    </li>
                    <li>
                      <a href="#">Exhaust System</a>
                    </li>
                  </ul>
                </div>
                <div class="col-lg-6">
                  <ul class="list-unstyled mb-0">
                    <li>
                      <a href="#">Interior Parts</a>
                    </li>
                    <li>
                      <a href="#">Exterior Parts</a>
                    </li>
                    <li>
                      <a href="#">Sound Systems</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <!-- Side Widget -->
          <div class="card my-4">
            <h5 class="card-header">Follow Us On Social Media</h5>
            <div class="card-body">
                <a class="fa fa-facebook" href="#"></a>
              <a class="fa fa-twitter" href="#"></a> 
              <a class="fa fa-instagram"></a>
              <a class="fa fa-snapchat-ghost" href="#"></a>  
              <a class="fa fa-youtube" href="#" ></a>
            </div>
          </div>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
          <h5 class="text-white">About Us:</h5>
          <a name ="About"><p class="m-0 text-left text-white">This website provides a service/community in which automotive enthusiast can come together and share their common interest in motor vehicles of any make of model, without ridicule. Not only will they be able to read blog post, but shared their common interest in motor vehicles, but be able to ask for help with certain aspect of their own cars. They can also, buy, sell and trade parts within this web service community that will be provided by this site.</p></a>
          <br>
        <p class="m-0 text-center text-white">Copyright &copy; GearHead Inc 2017</p>
      </div>
      <!-- /.container -->
    </footer>
      
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
